package com.kusuma.toyvideo;

import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.google.android.exoplayer2.ExoPlayerFactory;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.extractor.DefaultExtractorsFactory;
import com.google.android.exoplayer2.extractor.ExtractorsFactory;
import com.google.android.exoplayer2.source.ExtractorMediaSource;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.trackselection.AdaptiveTrackSelection;
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector;
import com.google.android.exoplayer2.trackselection.TrackSelector;
import com.google.android.exoplayer2.ui.SimpleExoPlayerView;
import com.google.android.exoplayer2.upstream.BandwidthMeter;
import com.google.android.exoplayer2.upstream.DefaultBandwidthMeter;
import com.google.android.exoplayer2.upstream.DefaultHttpDataSourceFactory;

public class MainActivity extends AppCompatActivity {
    SimpleExoPlayerView exo;
    SimpleExoPlayer sp;
    BandwidthMeter bm;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        exo=findViewById(R.id.exo_play);
        BandwidthMeter bm=new DefaultBandwidthMeter();
        TrackSelector ts=new DefaultTrackSelector(new AdaptiveTrackSelection.Factory(bm));
        sp= ExoPlayerFactory.newSimpleInstance(this,ts);
        Uri uri=Uri.parse("\n" + "http://clips.vorwaerts-gmbh.de/big_buck_bunny.mp4");
        DefaultHttpDataSourceFactory defaultHttpDataSourceFactory=new DefaultHttpDataSourceFactory("player");
        ExtractorsFactory ef=new DefaultExtractorsFactory();
        MediaSource ms=new ExtractorMediaSource(uri,defaultHttpDataSourceFactory,ef,null,null);
        exo.setPlayer(sp);
        sp.prepare(ms);
        sp.setPlayWhenReady(true);

    }

    @Override
    protected void onStop() {
        super.onStop();
        sp.stop();
    }

}

